# api_iris.py

from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
import os

# Charger le modèle depuis un chemin relatif (dans le conteneur Docker)
MODEL_PATH = "iris_model.dtree"

model = joblib.load(MODEL_PATH)

# Noms des classes
class_names = ["setosa", "versicolor", "virginica"]

# Schéma d’entrée 1
class IrisFeatures(BaseModel):
    sepal_length: float
    sepal_width: float
    petal_length: float
    petal_width: float

app = FastAPI(title="API Iris Classifier")

@app.get("/")
def read_root():
    return {"message": "Bienvenue sur l'API Iris - utilisez /predict ou  /predict-v2 pour prédire selon le schéma de votre entrée"}

@app.post("/predict")
def predict_species(features: IrisFeatures):
    input_data = np.array([[features.sepal_length, features.sepal_width,
                            features.petal_length, features.petal_width]])
    
    prediction = model.predict(input_data)[0]
    predicted_class = class_names[prediction]

    return {
        "prediction": int(prediction),
        "class_name": predicted_class
    }


# Schéma d’entrée 2
class IrisArrayInput(BaseModel):
    features: list[float]

@app.post("/predict-v2")
def predict_species_array(data: IrisArrayInput):
    if len(data.features) != 4:
        return {"error": "Exactement 4 valeurs requises"}
    
    input_data = np.array([data.features])
    prediction = model.predict(input_data)[0]
    predicted_class = class_names[prediction]

    return {
        "prediction": int(prediction),
        "class_name": predicted_class
    }

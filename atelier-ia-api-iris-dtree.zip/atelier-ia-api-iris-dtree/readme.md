#  docker build -t iris-app .
#  docker run -p 8000:8000 iris-app

curl --request POST \
  --url http://localhost:8000/predict \
  --header 'Content-Type: application/json' \
  --data '{
  "sepal_length": 0.1,
  "sepal_width": 0.9,
  "petal_length": 0.4,
  "petal_width": 0.2
}
'